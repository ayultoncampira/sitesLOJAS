/**
 * FLAVINHA STORE — ARQUIVO ÚNICO DE CONFIGURAÇÃO DE DADOS
 * 
 * Atualizado com base na identidade visual real observada no perfil @storeflavinha:
 * - Tipo de vestimenta: Moda Gaúcha, Campeira e Crioula (Palas de lã, Ponchos de tricot/jacquard,
 *   Bombachas, Chapéus campeiros, Lenços e Acessórios de tradição).
 * - Paleta de cores: Inspirada no Pampa gaúcho — Lã crua/areia (#F8F5F0), Bordô/Vinho Farroupilha (#6B1D2F),
 *   Marrom Couro/Tostado (#8B542E), Azul Crioulo (#1B2B44) e Preto Carvão (#221F1D).
 * - Fotos reais do perfil AINDA NÃO FORAM APLICADAS (conforme solicitação do usuário), mantendo
 *   fotografias ilustrativas temporárias correspondentes ao estilo campeiro/gaúcho em /images/.
 */

export interface ProductItem {
  id: string;
  name: string;
  category: string;
  price: string; // "Consulte o valor"
  priceNote?: string;
  statusBadge: string;
  primarySizes: string[];
  moreSizes: string[];
  sizes: string[];
  defaultSize: string;
  sizeType: "vestuario" | "chapeu" | "bombacha";
  imageUrl: string;
  altText: string;
  descriptionPlaceholder: string;
  accentTone: {
    bg: string;
    subtle: string;
    chip: string;
    textColor: string;
  };
}

export interface SizeMeasurement {
  size: string;
  manequim: string;
  busto: string;
  cintura: string;
  quadril: string;
  comprimento: string;
  descricao: string;
}

export interface CategoryItem {
  id: string;
  name: string;
  description: string;
  status: string;
}

export const flavinhaConfig = {
  // Informações Institucionais do Negócio
  business: {
    name: "Flavinha Store",
    city: "Bagé",
    state: "RS",
    cityState: "Bagé — RS",
    neighborhood: "São Judas",
    address: "R. Vinte e Um de Abril, 1576 - São Judas, Bagé - RS, 96415-480",
    phoneDisplay: "(53) 98445-0638",
    phoneRaw: "5553984450638",
    instagramHandle: "@storeflavinha",
    instagramUrl: "https://www.instagram.com/storeflavinha/",
    mapsUrl: "https://www.google.com/maps/search/?api=1&query=R.+Vinte+e+Um+de+Abril%2C+1576+-+S%C3%A3o+Judas%2C+Bag%C3%A9+-+RS%2C+96415-480",
    googleRating: "4,9",
    googleReviewsCount: "106 avaliações",
    deliveryInfo: "Oferece entrega",
    deliveryNote: "Consulte entregas para Bagé e região pelo WhatsApp",
    openingHours: "Consulte o horário de funcionamento",
    openingHoursNote: "Informação a confirmar com a loja",
    logoUrl: null as string | null,
  },

  // Textos Institucionais e Editoriais adaptados para a Tradição Campeira & Gaúcha de Bagé
  copy: {
    heroKicker: "Moda Gaúcha & Campeira",
    heroTitle: "Flavinha Store",
    heroSubtitle: "Palas de lã, ponchos exclusivos, bombachas e acessórios tradicionais em Bagé, RS. Escolha seu modelo na vitrine e fale diretamente pelo WhatsApp.",
    heroCtaPrimary: "Quero essa peça",
    heroCtaSecondary: "Ver vitrine de tradição",
    
    aboutKicker: "A Essência da Loja",
    aboutTitle: "Tradição, elegância e o orgulho do campo em Bagé",
    aboutDescription: "Localizada no bairro São Judas em Bagé (RS), a Flavinha Store veste quem vive e valoriza as tradições do Pampa gaúcho. Com avaliação 4,9 no Google (106 avaliações), reunimos palas, ponchos quentes, bombachas confortáveis e chapéus campeiros para cavalgadas, lida campeira, desfiles ou para o dia a dia, com a comodidade do atendimento pelo WhatsApp e entrega local.",
    
    categoriesKicker: "Linhas & Tradição",
    categoriesTitle: "Coleções & Vestuário Campeiro",
    categoriesSubtitle: "Peças de fabricação selecionada, tecidos quentes e detalhes autênticos. Consulte modelos disponíveis pelo WhatsApp.",

    locationKicker: "Loja Física em Bagé",
    locationTitle: "Visite nosso espaço campeiro",
    locationSubtitle: "Estamos na R. Vinte e Um de Abril, 1576, no bairro São Judas em Bagé. Venha provar nossas peças ou solicite atendimento com entrega.",
    locationButton: "Ver no Google Maps",

    instagramKicker: "Rede Social Oficial",
    instagramTitle: "Acompanhe a Flavinha Store no Instagram",
    instagramSubtitle: "Siga @storeflavinha para conferir lançamentos de palas, combinações com cavalos crioulos, fotos de clientes em cavalgadas e novidades da loja.",
    instagramButton: "Seguir @storeflavinha",

    finalCtaTitle: "Quer garantir uma peça da nossa vitrine?",
    finalCtaSubtitle: "Nosso atendimento é rápido e personalizado pelo WhatsApp. Consulte disponibilidade de cores, tamanhos ou combine sua entrega em Bagé e região.",
    finalCtaButton: "Pedir pelo WhatsApp",

    footerDisclaimer: "Esta é uma prévia comercial personalizada para a Flavinha Store. As fotos atuais são ilustrativas no estilo gaúcho/campeiro da loja e serão substituídas pelas fotos oficiais do catálogo.",
    footerCopyright: `© ${new Date().getFullYear()} Flavinha Store. Bagé - RS. Todos os direitos reservados.`,
  },

  // Vitrine de Peças-Destaque no estilo Campeiro / Gaúcho
  showcaseProducts: [
    {
      id: "peca-1",
      name: "Pala em Lã com Gola e Fivela",
      category: "Palas & Ponchos",
      price: "Consulte o valor",
      priceNote: "Valor e disponibilidade sob consulta",
      statusBadge: "Mais procurado no inverno",
      primarySizes: ["P", "M", "G"],
      moreSizes: ["PP", "GG", "XG", "Sob Medida"],
      sizes: ["PP", "P", "M", "G", "GG", "XG", "Sob Medida"],
      defaultSize: "M",
      sizeType: "vestuario",
      imageUrl: "/images/peca_destaque_1.jpg",
      altText: "Fotografia ilustrativa de pala de lã gaúcho com padronagem geométrica campeira",
      descriptionPlaceholder: "Confeccionado em lã macia com acabamento em debrum refinado e fecho em fivela metálica. Modelagem confortável para os dias frios de Bagé.",
      accentTone: {
        bg: "bg-[#F7F3EC]",
        subtle: "#EBDDCB",
        chip: "bg-[#EBDDCB] text-[#5C3920] border-[#D4BF9F]",
        textColor: "text-[#5C3920]"
      }
    },
    {
      id: "peca-2",
      name: "Poncho em Jacquard Reversível",
      category: "Linha Campeira Chic",
      price: "Consulte o valor",
      priceNote: "Valor e disponibilidade sob consulta",
      statusBadge: "Dupla face reversível",
      primarySizes: ["P", "M", "G"],
      moreSizes: ["PP", "GG", "XG", "Sob Medida"],
      sizes: ["PP", "P", "M", "G", "GG", "XG", "Sob Medida"],
      defaultSize: "M",
      sizeType: "vestuario",
      imageUrl: "/images/peca_destaque_2.jpg",
      altText: "Fotografia ilustrativa de poncho em jacquard com padronagem campeira e caimento refinado",
      descriptionPlaceholder: "Versatilidade e elegância em dupla face (dois tons). Tecido encorpado que proporciona caimento imponente tanto no campo quanto na cidade.",
      accentTone: {
        bg: "bg-[#F3F5F7]",
        subtle: "#D4DEE8",
        chip: "bg-[#D4DEE8] text-[#1B2B44] border-[#B8CADB]",
        textColor: "text-[#1B2B44]"
      }
    },
    {
      id: "peca-3",
      name: "Chapéu Campeiro com Barbicacho",
      category: "Acessórios & Tradição",
      price: "Consulte o valor",
      priceNote: "Valor e disponibilidade sob consulta",
      statusBadge: "Tradição & Estilo",
      primarySizes: ["54", "56", "58"],
      moreSizes: ["52", "60", "62", "Sob Medida"],
      sizes: ["52", "54", "56", "58", "60", "62", "Sob Medida"],
      defaultSize: "56",
      sizeType: "chapeu",
      imageUrl: "/images/peca_destaque_3.jpg",
      altText: "Fotografia ilustrativa de chapéu campeiro de aba com barbicacho de couro",
      descriptionPlaceholder: "Estrutura firme em feltro de alta densidade, aba moldada e barbicacho regulável. Disponível com opções de adornos florais femininos ou clássicos.",
      accentTone: {
        bg: "bg-[#F7F4F2]",
        subtle: "#E4DAD5",
        chip: "bg-[#E4DAD5] text-[#42312A] border-[#D1C2BB]",
        textColor: "text-[#42312A]"
      }
    },
    {
      id: "peca-4",
      name: "Pala / Capa Quente em Tricot Bordô",
      category: "Coleção Pampa",
      price: "Consulte o valor",
      priceNote: "Valor e disponibilidade sob consulta",
      statusBadge: "Destaque Bordô",
      primarySizes: ["P", "M", "G"],
      moreSizes: ["PP", "GG", "XG", "Sob Medida"],
      sizes: ["PP", "P", "M", "G", "GG", "XG", "Sob Medida"],
      defaultSize: "M",
      sizeType: "vestuario",
      imageUrl: "/images/peca_destaque_4.jpg",
      altText: "Fotografia ilustrativa de capa em tricot bordô com toque aveludado e gola envolvente",
      descriptionPlaceholder: "Tonalidade bordô marcante, inspirada nas cores tradicionais gaúchas. Tricot térmico envolvente com gola alta acolhedora.",
      accentTone: {
        bg: "bg-[#FAF2F3]",
        subtle: "#EED2D6",
        chip: "bg-[#EED2D6] text-[#6B1D2F] border-[#DCB0B7]",
        textColor: "text-[#6B1D2F]"
      }
    },
    {
      id: "peca-5",
      name: "Bombacha Campeira & Botas de Couro",
      category: "Indumentária Gaúcha",
      price: "Consulte o valor",
      priceNote: "Valor e disponibilidade sob consulta",
      statusBadge: "Conforto para montaria",
      primarySizes: ["36", "38", "40"],
      moreSizes: ["34", "42", "44", "46", "48", "Sob Medida"],
      sizes: ["34", "36", "38", "40", "42", "44", "46", "48", "Sob Medida"],
      defaultSize: "38",
      sizeType: "bombacha",
      imageUrl: "/images/peca_destaque_5.jpg",
      altText: "Fotografia ilustrativa de bombacha campeira e botas tradicionais de montaria",
      descriptionPlaceholder: "Modelagem anatômica com cós reforçado, pregas impecáveis e fivelas de ajuste. Ideal para cavalgadas e dias de campo.",
      accentTone: {
        bg: "bg-[#F5F4F0]",
        subtle: "#DDD9CE",
        chip: "bg-[#DDD9CE] text-[#3E382B] border-[#C8C2B3]",
        textColor: "text-[#3E382B]"
      }
    }
  ] as ProductItem[],

  // Auxílio de Medição & Tabela Completa de Medidas em Centímetros
  sizeGuideData: {
    title: "Guia de Medidas & Auxílio de Tamanho",
    subtitle: "Consulte as medidas exatas para cada tamanho e descubra qual veste melhor o seu corpo.",
    vestuario: [
      {
        size: "PP",
        manequim: "34 - 36",
        busto: "80 - 84 cm",
        cintura: "62 - 66 cm",
        quadril: "88 - 92 cm",
        comprimento: "75 cm",
        descricao: "Ideal para estaturas menores ou caimento mais ajustado."
      },
      {
        size: "P",
        manequim: "36 - 38",
        busto: "84 - 90 cm",
        cintura: "66 - 72 cm",
        quadril: "92 - 98 cm",
        comprimento: "78 cm",
        descricao: "Caimento suave e elegante, comprimento na altura do quadril."
      },
      {
        size: "M",
        manequim: "40 - 42",
        busto: "92 - 98 cm",
        cintura: "74 - 80 cm",
        quadril: "100 - 106 cm",
        comprimento: "82 cm",
        descricao: "Tamanho mais versátil, corte solto com ótimo movimento para sobreposições."
      },
      {
        size: "G",
        manequim: "44 - 46",
        busto: "100 - 108 cm",
        cintura: "82 - 90 cm",
        quadril: "108 - 116 cm",
        comprimento: "86 cm",
        descricao: "Amplo e aconchegante, excelente para usar sobre camisas e blusas térmicas."
      },
      {
        size: "GG",
        manequim: "48 - 50",
        busto: "110 - 118 cm",
        cintura: "92 - 100 cm",
        quadril: "118 - 126 cm",
        comprimento: "90 cm",
        descricao: "Modelagem generosa que garante liberdade total de movimento."
      },
      {
        size: "XG",
        manequim: "52 - 54+",
        busto: "120 - 130 cm",
        cintura: "102 - 114 cm",
        quadril: "128 - 138 cm",
        comprimento: "92 cm",
        descricao: "Tamanho extra com caimento solto e amplo conforto."
      },
      {
        size: "Sob Medida",
        manequim: "Personalizado",
        busto: "À sua escolha",
        cintura: "À sua escolha",
        quadril: "À sua escolha",
        comprimento: "Ajustável",
        descricao: "Feito de acordo com as suas medidas enviadas no WhatsApp."
      }
    ] as SizeMeasurement[],
    bombachas: [
      { size: "34", manequim: "PP", cintura: "64 - 68 cm", quadril: "86 - 90 cm", comprimento: "98 cm", descricao: "Cós estreito e pernas ajustadas." },
      { size: "36", manequim: "P", cintura: "68 - 72 cm", quadril: "90 - 94 cm", comprimento: "100 cm", descricao: "Manequim 36 padrão campeiro." },
      { size: "38", manequim: "P/M", cintura: "72 - 76 cm", quadril: "94 - 98 cm", comprimento: "102 cm", descricao: "Manequim 38 com fivelas de ajuste." },
      { size: "40", manequim: "M", cintura: "76 - 80 cm", quadril: "98 - 104 cm", comprimento: "103 cm", descricao: "Corte tradicional com pregas bem vincadas." },
      { size: "42", manequim: "M/G", cintura: "80 - 86 cm", quadril: "104 - 110 cm", comprimento: "104 cm", descricao: "Conforto para montaria e lida campeira." },
      { size: "44", manequim: "G", cintura: "86 - 92 cm", quadril: "110 - 116 cm", comprimento: "105 cm", descricao: "Cós alto com excelente sustentação." },
      { size: "46", manequim: "GG", cintura: "92 - 98 cm", quadril: "116 - 122 cm", comprimento: "106 cm", descricao: "Modelagem ampla." },
      { size: "48", manequim: "XG", cintura: "98 - 106 cm", quadril: "122 - 130 cm", comprimento: "107 cm", descricao: "Máximo conforto e amplitude." },
      { size: "Sob Medida", manequim: "Especial", cintura: "Personalizada", quadril: "Personalizado", comprimento: "Personalizado", descricao: "Ajustada para a sua altura e montaria." }
    ],
    chapeus: [
      { size: "52", manequim: "Infantil / Muito Pequeno", circunferencia: "52 - 53 cm", descricao: "Para cabeças pequenas ou público juvenil." },
      { size: "54", manequim: "Pequeno (P)", circunferencia: "54 - 55 cm", descricao: "Circunferência de 54 a 55 cm na linha da testa." },
      { size: "56", manequim: "Médio (M)", circunferencia: "56 - 57 cm", descricao: "Tamanho padrão mais comum para chapéu campeiro." },
      { size: "58", manequim: "Grande (G)", circunferencia: "58 - 59 cm", descricao: "Para quem prefere um encaixe mais folgado ou tem mais cabelo." },
      { size: "60", manequim: "Extra Grande (GG)", circunferencia: "60 - 61 cm", descricao: "Circunferência ampla com firmeza no barbicacho." },
      { size: "62", manequim: "Especial (XG)", circunferencia: "62 - 63 cm", descricao: "Estrutura especial sob consulta." },
      { size: "Sob Medida", manequim: "Personalizado", circunferencia: "Sua medida", descricao: "Conferido diretamente com a loja pelo WhatsApp." }
    ],
    howToMeasureTips: [
      {
        step: "1. Busto / Tórax",
        tip: "Passe a fita métrica horizontalmente ao redor do tórax, no ponto mais saliente do busto, mantendo os braços relaxados."
      },
      {
        step: "2. Cintura",
        tip: "Envolva a fita na parte mais estreita do tronco (normalmente 2 dedos acima do umbigo), sem apertar."
      },
      {
        step: "3. Quadril",
        tip: "Contorne a parte mais larga dos glúteos e quadris com a fita bem nivelada para escolher bombachas e saias."
      },
      {
        step: "4. Circunferência da Cabeça (Chapéus)",
        tip: "Passe a fita 1 dedo acima das orelhas e no meio da testa. A medida em centímetros (ex.: 56 cm) é o seu número."
      },
      {
        step: "5. Caimento de Palas & Ponchos",
        tip: "Palas e ponchos são peças de sobreposição. Se estiver em dúvida entre dois tamanhos, o maior oferece maior envergadura para cavalgar e se agasalhar."
      }
    ]
  },

  // Categorias Editoriais no segmento Campeiro & Tradicionalista
  categories: [
    {
      id: "cat-1",
      name: "Palas & Ponchos de Lã",
      description: "Palas de lã, ponchos em tricot jacquard, golas com fivela e modelos dupla face reversíveis.",
      status: "Consulte estampas no WhatsApp"
    },
    {
      id: "cat-2",
      name: "Bombachas Campeiras",
      description: "Modelos femininos, masculinos e infantis com corte impecável para montaria, desfiles e dia a dia.",
      status: "Numerações do 36 ao 48"
    },
    {
      id: "cat-3",
      name: "Chapéus Campeiros & Acessórios",
      description: "Chapéus de aba larga com barbicacho, aplicações florais femininas e faixas tradicionais.",
      status: "Diversos tamanhos e cores"
    },
    {
      id: "cat-4",
      name: "Lenços, Xales & Pelerines",
      description: "Acessórios de indumentária gaúcha que completam o look com sofisticação e conforto térmico.",
      status: "Novidades no @storeflavinha"
    }
  ] as CategoryItem[],

  // Imagem ilustrativa de ambiente campeiro da loja
  storeAmbienceImage: {
    url: "/images/loja_ambiente.jpg",
    altText: "Ambiente ilustrativo rústico com peças de vestuário e tricot campeiro",
    disclaimer: "Ambiente ilustrativo provisório · Em breve fotos oficiais da loja"
  },

  // Gerador de links com mensagens pré-formatadas para o WhatsApp
  getWhatsAppProductLink: (productName: string, selectedSize?: string): string => {
    const sizePhrase = selectedSize ? ` (tamanho ${selectedSize})` : "";
    const message = `Olá! Gostei da peça "${productName}"${sizePhrase} na vitrine da Flavinha Store e gostaria de consultar o valor e cores disponíveis.`;
    return `https://wa.me/5553984450638?text=${encodeURIComponent(message)}`;
  },

  getWhatsAppGeneralLink: (context = "informações"): string => {
    const message = `Olá! Gostaria de mais ${context} sobre as peças campeiras e palas da Flavinha Store.`;
    return `https://wa.me/5553984450638?text=${encodeURIComponent(message)}`;
  }
};
