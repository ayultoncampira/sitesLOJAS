import React from 'react';
import { CommercialPreviewNotice } from './components/CommercialPreviewNotice';
import { Navbar } from './components/Navbar';
import { InteractiveShowcase } from './components/InteractiveShowcase';
import { AboutSection } from './components/AboutSection';
import { CategoriesSection } from './components/CategoriesSection';
import { LocationSection } from './components/LocationSection';
import { InstagramSection } from './components/InstagramSection';
import { FinalCtaSection } from './components/FinalCtaSection';
import { Footer } from './components/Footer';
import { MessageCircle } from 'lucide-react';
import { flavinhaConfig } from './data/flavinhaConfig';

export default function App() {
  return (
    <div className="min-h-screen flex flex-col bg-[#F8F5F0] text-[#221F1D] selection:bg-[#6B1D2F] selection:text-white">
      {/* Top Banner indicating Commercial Preview status */}
      <CommercialPreviewNotice />

      {/* Main Top Navigation */}
      <Navbar />

      {/* Main Content Area */}
      <main className="flex-grow">
        {/* 1. Signature Hero Showcase */}
        <InteractiveShowcase />

        {/* 2. Identity / About the Store */}
        <AboutSection />

        {/* 3. Editorial Categories & Collections */}
        <CategoriesSection />

        {/* 4. Physical Store Location & Delivery */}
        <LocationSection />

        {/* 5. Instagram Profile */}
        <InstagramSection />

        {/* 6. Final WhatsApp Call to Action */}
        <FinalCtaSection />
      </main>

      {/* Footer */}
      <Footer />

      {/* Floating WhatsApp Quick Action Button for Mobile & Desktop */}
      <aside aria-label="Ações rápidas">
        <a
          href={flavinhaConfig.getWhatsAppGeneralLink()}
          target="_blank"
          rel="noopener noreferrer"
          className="fixed bottom-6 right-6 z-50 flex items-center gap-2 bg-emerald-600 hover:bg-emerald-700 text-white py-3 px-4 shadow-xl transition-all duration-200 hover:scale-105 active:scale-95 group focus:outline-none focus:ring-2 focus:ring-emerald-500 focus:ring-offset-2"
          aria-label="Abrir conversa no WhatsApp"
        >
          <MessageCircle className="w-5 h-5 text-white" />
          <span className="text-xs font-semibold uppercase tracking-wider hidden sm:inline">
            WhatsApp
          </span>
        </a>
      </aside>
    </div>
  );
}
