import React from 'react';
import { MessageCircle, Instagram, MapPin, ExternalLink } from 'lucide-react';
import { flavinhaConfig } from '../data/flavinhaConfig';

export const Footer: React.FC = () => {
  return (
    <footer className="bg-[#FAF7F2] border-t border-[#E8DFD3] text-[#4A3E38] py-12 sm:py-16">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        <div className="grid grid-cols-1 md:grid-cols-12 gap-8 lg:gap-12 pb-12 border-b border-[#E2D7C9]">
          
          {/* Brand Info */}
          <div className="md:col-span-5 space-y-4">
            <a href="#" className="font-serif text-2xl font-semibold text-[#221F1D] tracking-tight block hover:text-[#6B1D2F] transition-colors">
              {flavinhaConfig.business.name}
            </a>
            <p className="text-[#5A4D45] text-xs sm:text-sm leading-relaxed max-w-sm">
              Vitrine digital de moda gaúcha, palas, ponchos, bombachas e acessórios tradicionais em {flavinhaConfig.business.cityState}. Atendimento humanizado e vendas diretas pelo WhatsApp.
            </p>
            <div className="text-xs text-[#736357] pt-2">
              Nota <strong>{flavinhaConfig.business.googleRating}</strong> no Google ({flavinhaConfig.business.googleReviewsCount})
            </div>
          </div>

          {/* Quick Links */}
          <div className="md:col-span-3 space-y-3">
            <div className="text-xs font-semibold uppercase tracking-wider text-[#221F1D]">
              Navegação
            </div>
            <ul className="space-y-2 text-xs sm:text-sm">
              <li>
                <a href="#vitrine" className="text-[#5A4D45] hover:text-[#6B1D2F] transition-colors">
                  Vitrine Campeira
                </a>
              </li>
              <li>
                <a href="#sobre" className="text-[#5A4D45] hover:text-[#6B1D2F] transition-colors">
                  A Loja em Bagé
                </a>
              </li>
              <li>
                <a href="#colecoes" className="text-[#5A4D45] hover:text-[#6B1D2F] transition-colors">
                  Palas, Ponchos & Bombachas
                </a>
              </li>
              <li>
                <a href="#localizacao" className="text-[#5A4D45] hover:text-[#6B1D2F] transition-colors">
                  Localização & Entrega
                </a>
              </li>
            </ul>
          </div>

          {/* Contact Details */}
          <div className="md:col-span-4 space-y-3">
            <div className="text-xs font-semibold uppercase tracking-wider text-[#221F1D]">
              Contatos & Endereço
            </div>
            <div className="space-y-2 text-xs sm:text-sm text-[#5A4D45]">
              <div className="flex items-start gap-2">
                <MapPin className="w-4 h-4 text-[#6B1D2F] shrink-0 mt-0.5" />
                <span>{flavinhaConfig.business.address}</span>
              </div>
              <div className="flex items-center gap-2">
                <MessageCircle className="w-4 h-4 text-emerald-600 shrink-0" />
                <a 
                  href={flavinhaConfig.getWhatsAppGeneralLink()} 
                  target="_blank" 
                  rel="noopener noreferrer"
                  className="hover:text-[#6B1D2F] transition-colors font-medium text-[#221F1D]"
                >
                  WhatsApp: {flavinhaConfig.business.phoneDisplay}
                </a>
              </div>
              <div className="flex items-center gap-2">
                <Instagram className="w-4 h-4 text-[#7A4725] shrink-0" />
                <a 
                  href={flavinhaConfig.business.instagramUrl} 
                  target="_blank" 
                  rel="noopener noreferrer"
                  className="hover:text-[#6B1D2F] transition-colors"
                >
                  {flavinhaConfig.business.instagramHandle}
                </a>
              </div>
              <div className="pt-1">
                <a 
                  href={flavinhaConfig.business.mapsUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center gap-1 text-xs text-[#6B1D2F] font-semibold hover:underline"
                >
                  <span>Abrir no Google Maps</span>
                  <ExternalLink className="w-3 h-3" />
                </a>
              </div>
            </div>
          </div>

        </div>

        {/* Commercial Preview Disclaimer & Copyright */}
        <div className="pt-8 flex flex-col md:flex-row items-center justify-between gap-4 text-xs text-[#736357]">
          <p className="text-center md:text-left max-w-2xl leading-relaxed">
            {flavinhaConfig.copy.footerDisclaimer}
          </p>
          <div className="shrink-0 text-center md:text-right">
            {flavinhaConfig.copy.footerCopyright}
          </div>
        </div>

      </div>
    </footer>
  );
};
