import React from 'react';
import { Instagram, ArrowUpRight } from 'lucide-react';
import { flavinhaConfig } from '../data/flavinhaConfig';

export const InstagramSection: React.FC = () => {
  return (
    <section className="py-16 sm:py-20 bg-white border-t border-[#E8DFD3]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="border border-[#DDD3C5] p-8 sm:p-12 bg-[#FAF7F2] flex flex-col md:flex-row items-center justify-between gap-8 shadow-sm">
          <div className="space-y-3 text-center md:text-left max-w-xl">
            <div className="flex items-center justify-center md:justify-start gap-2 text-xs font-semibold tracking-widest text-[#7A4725] uppercase">
              <Instagram className="w-4 h-4 text-[#6B1D2F]" />
              <span>{flavinhaConfig.copy.instagramKicker}</span>
            </div>
            <h2 className="font-serif text-2xl sm:text-3xl lg:text-4xl font-semibold text-[#221F1D] tracking-tight">
              {flavinhaConfig.copy.instagramTitle}
            </h2>
            <p className="text-[#5A4D45] text-sm leading-relaxed">
              {flavinhaConfig.copy.instagramSubtitle}
            </p>
          </div>

          <div className="flex flex-col sm:flex-row items-center gap-4 shrink-0">
            <div className="text-center sm:text-right">
              <div className="font-serif text-xl font-medium text-[#221F1D]">
                {flavinhaConfig.business.instagramHandle}
              </div>
              <div className="text-xs text-[#736357]">
                Perfil Oficial no Instagram
              </div>
            </div>

            <a
              href={flavinhaConfig.business.instagramUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-2 px-6 py-3.5 text-xs font-semibold uppercase tracking-wider text-white bg-[#6B1D2F] hover:bg-[#521523] transition-colors shadow-sm group"
            >
              <span>{flavinhaConfig.copy.instagramButton}</span>
              <ArrowUpRight className="w-4 h-4 group-hover:translate-x-0.5 group-hover:-translate-y-0.5 transition-transform" />
            </a>
          </div>
        </div>
      </div>
    </section>
  );
};
