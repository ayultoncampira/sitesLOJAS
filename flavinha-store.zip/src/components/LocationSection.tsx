import React from 'react';
import { MapPin, Navigation, Clock, Truck, ExternalLink } from 'lucide-react';
import { flavinhaConfig } from '../data/flavinhaConfig';

export const LocationSection: React.FC = () => {
  return (
    <section id="localizacao" className="py-16 sm:py-24 bg-[#FAF7F2] border-t border-[#E8DFD3]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="max-w-2xl mb-12 sm:mb-16">
          <div className="text-xs font-semibold tracking-widest text-[#7A4725] uppercase mb-2">
            {flavinhaConfig.copy.locationKicker}
          </div>
          <h2 className="font-serif text-3xl sm:text-4xl lg:text-5xl font-semibold text-[#221F1D] tracking-tight">
            {flavinhaConfig.copy.locationTitle}
          </h2>
          <p className="mt-3 text-[#5A4D45] text-sm sm:text-base">
            {flavinhaConfig.copy.locationSubtitle}
          </p>
        </div>

        {/* Location Info Card Grid */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-10">
          
          {/* Address Card */}
          <div className="p-6 bg-white border border-[#DDD3C5] flex flex-col justify-between shadow-sm">
            <div>
              <div className="w-10 h-10 border border-[#D8C7B5] flex items-center justify-center text-[#6B1D2F] mb-4 bg-[#FAF7F2]">
                <MapPin className="w-5 h-5" />
              </div>
              <h3 className="font-serif text-lg font-semibold text-[#221F1D]">
                Endereço em Bagé
              </h3>
              <p className="mt-2 text-[#5A4D45] text-sm leading-relaxed">
                {flavinhaConfig.business.address}
              </p>
              <div className="text-xs text-[#736357] mt-2">
                Bairro {flavinhaConfig.business.neighborhood} · {flavinhaConfig.business.city} ({flavinhaConfig.business.state})
              </div>
            </div>

            <div className="mt-6 pt-4 border-t border-[#EFEAE2]">
              <a
                href={flavinhaConfig.business.mapsUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-2 text-xs font-semibold text-[#6B1D2F] hover:text-[#521523] uppercase tracking-wider group"
              >
                <span>{flavinhaConfig.copy.locationButton}</span>
                <ExternalLink className="w-3.5 h-3.5 group-hover:translate-x-0.5 group-hover:-translate-y-0.5 transition-transform" />
              </a>
            </div>
          </div>

          {/* Delivery Card */}
          <div className="p-6 bg-white border border-[#DDD3C5] flex flex-col justify-between shadow-sm">
            <div>
              <div className="w-10 h-10 border border-[#D8C7B5] flex items-center justify-center text-[#7A4725] mb-4 bg-[#FAF7F2]">
                <Truck className="w-5 h-5" />
              </div>
              <h3 className="font-serif text-lg font-semibold text-[#221F1D]">
                Serviço de Entrega
              </h3>
              <p className="mt-2 text-[#5A4D45] text-sm leading-relaxed">
                {flavinhaConfig.business.deliveryInfo} para quem deseja comodidade ao receber suas peças.
              </p>
              <div className="text-xs text-[#736357] mt-2">
                {flavinhaConfig.business.deliveryNote}
              </div>
            </div>

            <div className="mt-6 pt-4 border-t border-[#EFEAE2]">
              <a
                href={flavinhaConfig.getWhatsAppGeneralLink("informações sobre entrega")}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-2 text-xs font-semibold text-[#6B1D2F] hover:text-[#521523] uppercase tracking-wider"
              >
                <span>Solicitar entrega</span>
                <Navigation className="w-3.5 h-3.5" />
              </a>
            </div>
          </div>

          {/* Opening Hours Card */}
          <div className="p-6 bg-white border border-[#DDD3C5] flex flex-col justify-between shadow-sm">
            <div>
              <div className="w-10 h-10 border border-[#D8C7B5] flex items-center justify-center text-[#221F1D] mb-4 bg-[#FAF7F2]">
                <Clock className="w-5 h-5" />
              </div>
              <h3 className="font-serif text-lg font-semibold text-[#221F1D]">
                Horário de Atendimento
              </h3>
              <p className="mt-2 text-[#5A4D45] text-sm leading-relaxed font-medium">
                {flavinhaConfig.business.openingHours}
              </p>
              <div className="text-xs text-[#736357] mt-2">
                {flavinhaConfig.business.openingHoursNote}
              </div>
            </div>

            <div className="mt-6 pt-4 border-t border-[#EFEAE2]">
              <a
                href={flavinhaConfig.getWhatsAppGeneralLink("saber o horário de atendimento")}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-2 text-xs font-semibold text-[#6B1D2F] hover:text-[#521523] uppercase tracking-wider"
              >
                <span>Consultar no WhatsApp</span>
                <Navigation className="w-3.5 h-3.5" />
              </a>
            </div>
          </div>

        </div>

        {/* Embedded Interactive Route Action */}
        <div className="p-8 sm:p-10 bg-[#221F1D] text-white flex flex-col md:flex-row items-center justify-between gap-6 border-l-4 border-[#6B1D2F]">
          <div className="space-y-2 text-center md:text-left">
            <div className="text-xs font-semibold uppercase tracking-widest text-amber-400">
              Traçar Rota no Mapa
            </div>
            <div className="font-serif text-2xl sm:text-3xl font-medium">
              Venha visitar nosso espaço físico em Bagé
            </div>
            <p className="text-[#C5B8AC] text-xs sm:text-sm max-w-xl">
              R. Vinte e Um de Abril, 1576 - São Judas, Bagé - RS. Clique no botão ao lado para abrir a rota direta no Google Maps.
            </p>
          </div>

          <a
            href={flavinhaConfig.business.mapsUrl}
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center gap-3 px-7 py-4 text-xs font-semibold uppercase tracking-wider text-white bg-[#6B1D2F] hover:bg-[#521523] transition-colors shrink-0 shadow-md active:scale-95"
          >
            <Navigation className="w-4 h-4 text-white" />
            <span>Como Chegar (Google Maps)</span>
          </a>
        </div>

      </div>
    </section>
  );
};
