import React, { useState } from 'react';
import { X, Sparkles } from 'lucide-react';
import { flavinhaConfig } from '../data/flavinhaConfig';

export const CommercialPreviewNotice: React.FC = () => {
  const [isVisible, setIsVisible] = useState(true);

  if (!isVisible) return null;

  return (
    <aside aria-label="Aviso de prévia comercial" className="bg-[#221F1D] text-[#DDD3C5] text-xs py-2 px-4 border-b border-[#3D332B] transition-all">
      <div className="max-w-7xl mx-auto flex items-center justify-between gap-4">
        <div className="flex items-center gap-2 overflow-hidden text-ellipsis whitespace-nowrap">
          <Sparkles className="w-3.5 h-3.5 text-amber-400 shrink-0" />
          <span className="font-semibold text-white">Prévia Comercial:</span>
          <span className="text-[#C5B8AC] hidden sm:inline">
            Identidade alinhada à Moda Gaúcha & Campeira da {flavinhaConfig.business.name} (Bagé - RS). Fotos ilustrativas temporárias aguardando envio do catálogo oficial.
          </span>
          <span className="text-[#C5B8AC] sm:hidden">
            Moda Gaúcha da {flavinhaConfig.business.name} (Bagé - RS) · Fotos temporárias.
          </span>
        </div>
        <button
          onClick={() => setIsVisible(false)}
          className="text-[#99887B] hover:text-white p-1 transition-colors shrink-0"
          aria-label="Fechar aviso"
        >
          <X className="w-3.5 h-3.5" />
        </button>
      </div>
    </aside>
  );
};
