import React from 'react';
import { MessageCircle, ArrowRight, ShieldCheck, Clock, Award } from 'lucide-react';
import { flavinhaConfig } from '../data/flavinhaConfig';

export const FinalCtaSection: React.FC = () => {
  return (
    <section className="py-20 sm:py-28 bg-[#221F1D] text-white relative overflow-hidden">
      {/* Subtle background glow */}
      <div className="absolute top-0 right-1/4 w-96 h-96 bg-[#6B1D2F]/20 blur-3xl rounded-full pointer-events-none" />
      <div className="absolute bottom-0 left-1/4 w-96 h-96 bg-[#7A4725]/15 blur-3xl rounded-full pointer-events-none" />

      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center relative z-10 space-y-8">
        
        <div className="inline-flex items-center gap-2 px-3.5 py-1.5 border border-[#4A3B34] bg-[#2E2824] text-amber-300 text-xs uppercase tracking-widest">
          <Award className="w-3.5 h-3.5 text-amber-400" />
          <span>Tradição Gaúcha & Moda Campeira em Bagé</span>
        </div>

        <h2 className="font-serif text-3xl sm:text-5xl font-medium tracking-tight leading-tight">
          {flavinhaConfig.copy.finalCtaTitle}
        </h2>

        <p className="text-[#C5B8AC] text-base sm:text-lg max-w-2xl mx-auto leading-relaxed">
          {flavinhaConfig.copy.finalCtaSubtitle}
        </p>

        <div className="pt-4 flex flex-col sm:flex-row items-center justify-center gap-4">
          <a
            href={flavinhaConfig.getWhatsAppGeneralLink("comprar ou saber mais sobre palas e ponchos")}
            target="_blank"
            rel="noopener noreferrer"
            className="w-full sm:w-auto inline-flex items-center justify-center gap-3 py-4 px-8 text-xs font-semibold uppercase tracking-wider text-white bg-[#6B1D2F] hover:bg-[#521523] transition-all shadow-xl group"
          >
            <MessageCircle className="w-4 h-4 text-emerald-300 group-hover:scale-110 transition-transform" />
            <span>{flavinhaConfig.copy.finalCtaButton}</span>
            <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
          </a>

          <a
            href={flavinhaConfig.business.instagramUrl}
            target="_blank"
            rel="noopener noreferrer"
            className="w-full sm:w-auto inline-flex items-center justify-center gap-2 py-4 px-8 text-xs font-semibold uppercase tracking-wider text-[#E8DFD3] border border-[#52443C] hover:bg-[#332A24] transition-colors"
          >
            <span>Ver @storeflavinha</span>
          </a>
        </div>

        {/* Quiet assurance points */}
        <div className="pt-8 border-t border-[#3A322C] flex flex-wrap items-center justify-center gap-6 text-xs text-[#A6978A]">
          <div className="flex items-center gap-1.5">
            <ShieldCheck className="w-4 h-4 text-amber-400" />
            <span>Loja física em Bagé - RS</span>
          </div>
          <span className="hidden sm:inline" aria-hidden="true">·</span>
          <div className="flex items-center gap-1.5">
            <MessageCircle className="w-4 h-4 text-emerald-400" />
            <span>WhatsApp {flavinhaConfig.business.phoneDisplay}</span>
          </div>
          <span className="hidden sm:inline" aria-hidden="true">·</span>
          <div className="flex items-center gap-1.5">
            <Clock className="w-4 h-4 text-amber-400" />
            <span>Opção de entrega local</span>
          </div>
        </div>

      </div>
    </section>
  );
};
