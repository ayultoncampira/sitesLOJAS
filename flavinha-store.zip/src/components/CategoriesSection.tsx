import React, { useState } from 'react';
import { ArrowUpRight, MessageCircle, Ruler, CheckCircle } from 'lucide-react';
import { flavinhaConfig } from '../data/flavinhaConfig';
import { SizeGuideModal } from './SizeGuideModal';

export const CategoriesSection: React.FC = () => {
  const [isSizeGuideOpen, setIsSizeGuideOpen] = useState(false);

  return (
    <section id="colecoes" className="py-16 sm:py-24 bg-white border-t border-[#E8DFD3]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-12 sm:mb-16 gap-6">
          <div className="max-w-2xl">
            <div className="text-xs font-semibold tracking-widest text-[#7A4725] uppercase mb-2">
              {flavinhaConfig.copy.categoriesKicker}
            </div>
            <h2 className="font-serif text-3xl sm:text-4xl lg:text-5xl font-semibold text-[#221F1D] tracking-tight">
              {flavinhaConfig.copy.categoriesTitle}
            </h2>
            <p className="mt-3 text-[#5A4D45] text-sm sm:text-base">
              {flavinhaConfig.copy.categoriesSubtitle}
            </p>
          </div>

          {/* Quick link to Guia de Medidas */}
          <button
            onClick={() => setIsSizeGuideOpen(true)}
            className="inline-flex items-center gap-2 px-4 py-2.5 text-xs font-semibold uppercase tracking-wider text-[#6B1D2F] bg-[#FAF7F2] border border-[#D8C7B5] hover:border-[#6B1D2F] hover:bg-white transition-all shadow-xs cursor-pointer self-start md:self-end"
          >
            <Ruler className="w-4 h-4 text-[#7A4725]" />
            <span>Consultar Tabela de Medidas (cm)</span>
          </button>
        </div>

        {/* Editorial Categories Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {flavinhaConfig.categories.map((cat, index) => (
            <div
              key={cat.id}
              className="p-6 border border-[#DDD3C5] bg-[#FAF7F2] flex flex-col justify-between hover:border-[#6B1D2F] transition-all group"
            >
              <div>
                <div className="text-xs font-serif text-[#6B1D2F] font-semibold mb-4 tabular-nums">
                  0{index + 1} //
                </div>
                <h3 className="font-serif text-xl font-semibold text-[#221F1D] group-hover:text-[#6B1D2F] transition-colors">
                  {cat.name}
                </h3>
                <p className="mt-2.5 text-[#5A4D45] text-xs sm:text-sm leading-relaxed">
                  {cat.description}
                </p>
              </div>

              <div className="mt-6 pt-4 border-t border-[#E2D7C9] flex items-center justify-between">
                <span className="text-xs font-medium text-[#736357]">
                  {cat.status}
                </span>
                <a
                  href={flavinhaConfig.getWhatsAppGeneralLink(`informações sobre a linha de ${cat.name}`)}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="w-9 h-9 flex items-center justify-center border border-[#D8C7B5] bg-white group-hover:bg-[#6B1D2F] group-hover:text-white group-hover:border-[#6B1D2F] transition-colors shadow-sm"
                  aria-label={`Consultar ${cat.name} no WhatsApp`}
                >
                  <ArrowUpRight className="w-4 h-4" />
                </a>
              </div>
            </div>
          ))}
        </div>

        {/* Measurement Help & Catalog Consultation Card */}
        <div className="mt-10 p-6 sm:p-8 bg-[#FAF5EE] border border-[#DDD3C5] flex flex-col md:flex-row items-start md:items-center justify-between gap-6">
          <div className="space-y-2">
            <div className="flex items-center gap-2 text-xs font-semibold text-[#7A4725] uppercase tracking-wider">
              <CheckCircle className="w-4 h-4 text-emerald-700" />
              <span>Dúvida com manequim ou tamanho de pala?</span>
            </div>
            <div className="font-serif text-xl font-medium text-[#221F1D]">
              Ajudamos a conferir seu tamanho exato no WhatsApp
            </div>
            <p className="text-xs sm:text-sm text-[#5A4D45] max-w-xl">
              Nossa equipe orienta a medição do tórax, cintura ou circunferência da cabeça para garantir o caimento perfeito no seu corpo.
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-3 shrink-0">
            <button
              onClick={() => setIsSizeGuideOpen(true)}
              className="px-5 py-3.5 text-xs font-semibold uppercase tracking-wider text-[#4A3E38] bg-white border border-[#D8C7B5] hover:border-[#6B1D2F] transition-colors shadow-xs cursor-pointer"
            >
              Ver Tabela de Medidas
            </button>
            <a
              href={flavinhaConfig.getWhatsAppGeneralLink("consultar mais modelos de palas e bombachas")}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-2 px-6 py-3.5 text-xs font-semibold uppercase tracking-wider text-white bg-[#6B1D2F] hover:bg-[#521523] transition-colors shadow-sm"
            >
              <MessageCircle className="w-4 h-4 text-emerald-300" />
              <span>Falar no WhatsApp</span>
            </a>
          </div>
        </div>

      </div>

      <SizeGuideModal
        isOpen={isSizeGuideOpen}
        onClose={() => setIsSizeGuideOpen(false)}
        initialCategory="vestuario"
      />
    </section>
  );
};
