import React from 'react';
import { Star, Truck, HeartHandshake, MapPin, Compass } from 'lucide-react';
import { flavinhaConfig } from '../data/flavinhaConfig';

export const AboutSection: React.FC = () => {
  return (
    <section id="sobre" className="py-16 sm:py-24 bg-[#FAF7F2] border-t border-[#E8DFD3]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
          
          {/* Visual Column: Store / Ambience Photography */}
          <div className="lg:col-span-6 relative">
            <div className="relative overflow-hidden bg-[#EFEAE2] border border-[#DDD3C5] aspect-[4/3] shadow-sm">
              <img
                src={flavinhaConfig.storeAmbienceImage.url}
                alt={flavinhaConfig.storeAmbienceImage.altText}
                referrerPolicy="no-referrer"
                className="w-full h-full object-cover"
              />
              <div className="absolute bottom-3 left-3 bg-white/95 backdrop-blur-sm px-2.5 py-1 text-[11px] font-medium text-[#5C4535] border border-[#DDD3C5]">
                {flavinhaConfig.storeAmbienceImage.disclaimer}
              </div>
            </div>

            {/* Google Rating Fact Card */}
            <div className="absolute -bottom-6 right-4 sm:-bottom-8 sm:right-8 bg-white border border-[#D8C7B5] p-4 sm:p-5 shadow-lg max-w-xs">
              <div className="flex items-center gap-2">
                <div className="flex text-amber-500">
                  {[...Array(5)].map((_, i) => (
                    <Star key={i} className="w-4 h-4 fill-amber-500 text-amber-500" />
                  ))}
                </div>
                <span className="font-bold text-[#221F1D] text-lg tabular-nums">
                  {flavinhaConfig.business.googleRating}
                </span>
              </div>
              <div className="text-xs text-[#5A4D45] mt-1 font-medium">
                Avaliação no Google · {flavinhaConfig.business.googleReviewsCount}
              </div>
            </div>
          </div>

          {/* Text Information Column */}
          <div className="lg:col-span-6 space-y-6 pt-6 lg:pt-0">
            <div className="flex items-center gap-2 text-xs font-semibold tracking-widest text-[#7A4725] uppercase">
              <Compass className="w-3.5 h-3.5 text-[#6B1D2F]" />
              <span>{flavinhaConfig.copy.aboutKicker}</span>
            </div>
            
            <h2 className="font-serif text-3xl sm:text-4xl font-semibold text-[#221F1D] tracking-tight leading-snug">
              {flavinhaConfig.copy.aboutTitle}
            </h2>
            
            <p className="text-[#5A4D45] leading-relaxed text-base sm:text-lg">
              {flavinhaConfig.copy.aboutDescription}
            </p>

            {/* Real Factual Highlights based solely on briefing */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-4 border-t border-[#E8DFD3]">
              <div className="flex items-start gap-3">
                <div className="w-10 h-10 border border-[#D8C7B5] bg-white flex items-center justify-center shrink-0">
                  <MapPin className="w-4 h-4 text-[#6B1D2F]" />
                </div>
                <div>
                  <div className="text-xs font-semibold text-[#221F1D] uppercase tracking-wide">Espaço em Bagé</div>
                  <div className="text-xs text-[#5A4D45] mt-0.5">Bairro {flavinhaConfig.business.neighborhood}, Bagé - RS</div>
                </div>
              </div>

              <div className="flex items-start gap-3">
                <div className="w-10 h-10 border border-[#D8C7B5] bg-white flex items-center justify-center shrink-0">
                  <Truck className="w-4 h-4 text-[#7A4725]" />
                </div>
                <div>
                  <div className="text-xs font-semibold text-[#221F1D] uppercase tracking-wide">{flavinhaConfig.business.deliveryInfo}</div>
                  <div className="text-xs text-[#5A4D45] mt-0.5">Entregas em Bagé e envios sob consulta</div>
                </div>
              </div>

              <div className="flex items-start gap-3">
                <div className="w-10 h-10 border border-[#D8C7B5] bg-white flex items-center justify-center shrink-0">
                  <HeartHandshake className="w-4 h-4 text-[#6B1D2F]" />
                </div>
                <div>
                  <div className="text-xs font-semibold text-[#221F1D] uppercase tracking-wide">Atendimento Próximo</div>
                  <div className="text-xs text-[#5A4D45] mt-0.5">Contato direto com a loja via WhatsApp</div>
                </div>
              </div>

              <div className="flex items-start gap-3">
                <div className="w-10 h-10 border border-[#D8C7B5] bg-white flex items-center justify-center shrink-0">
                  <Star className="w-4 h-4 text-amber-600" />
                </div>
                <div>
                  <div className="text-xs font-semibold text-[#221F1D] uppercase tracking-wide">Nota Máxima no Google</div>
                  <div className="text-xs text-[#5A4D45] mt-0.5">4,9 estrelas com 106 avaliações</div>
                </div>
              </div>
            </div>

          </div>

        </div>
      </div>
    </section>
  );
};
