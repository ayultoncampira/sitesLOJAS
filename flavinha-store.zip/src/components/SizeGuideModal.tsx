import React, { useState } from 'react';
import { X, Ruler, Check, HelpCircle, MessageCircle, Sparkles, ChevronRight } from 'lucide-react';
import { flavinhaConfig } from '../data/flavinhaConfig';

interface SizeGuideModalProps {
  isOpen: boolean;
  onClose: () => void;
  initialCategory?: "vestuario" | "bombacha" | "chapeu";
  selectedSize?: string;
  productName?: string;
}

export const SizeGuideModal: React.FC<SizeGuideModalProps> = ({
  isOpen,
  onClose,
  initialCategory = "vestuario",
  selectedSize,
  productName,
}) => {
  const [activeTab, setActiveTab] = useState<"vestuario" | "bombacha" | "chapeu">(initialCategory);
  
  // Quick Size Finder State (Auxílio interativo)
  const [habitualManequim, setHabitualManequim] = useState<string>("40");

  if (!isOpen) return null;

  const { sizeGuideData } = flavinhaConfig;

  // Recommendation engine based on habitual manequim
  const getRecommendation = (manequim: string) => {
    const num = parseInt(manequim, 10);
    if (isNaN(num)) return { size: "M", tip: "Manequim versátil com caimento confortável." };
    if (num <= 36) return { size: "P (ou PP)", tip: "Ideal para estaturas menores ou corte mais ajustado ao corpo." };
    if (num <= 40) return { size: "M", tip: "Caimento perfeito com liberdade para usar sobreposições térmicas." };
    if (num <= 44) return { size: "G", tip: "Corte amplo e envolvente, excelente para palas de inverno e montaria." };
    if (num <= 48) return { size: "GG", tip: "Modelagem generosa que garante mobilidade total no lombo do cavalo." };
    return { size: "XG (ou Sob Medida)", tip: "Tamanho extra com máxima amplitude e conforto térmico." };
  };

  const currentRecommendation = getRecommendation(habitualManequim);

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-black/60 backdrop-blur-sm flex items-center justify-center p-3 sm:p-6 animate-in fade-in duration-200">
      <div 
        className="relative w-full max-w-4xl bg-[#FAF7F2] border border-[#D8C7B5] shadow-2xl overflow-hidden flex flex-col max-h-[92vh]"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Modal Header */}
        <div className="bg-[#221F1D] text-white px-6 py-5 flex items-center justify-between border-b border-[#3D332B] shrink-0">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 border border-[#6B1D2F] bg-[#332A24] flex items-center justify-center text-amber-400">
              <Ruler className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2 text-xs font-semibold uppercase tracking-widest text-amber-400">
                <span>Auxílio de Medição</span>
                {productName && (
                  <>
                    <span aria-hidden="true">·</span>
                    <span className="text-[#C5B8AC] truncate max-w-xs">{productName}</span>
                  </>
                )}
              </div>
              <h2 className="font-serif text-xl sm:text-2xl font-semibold tracking-tight text-white">
                Guia de Medidas & Tamanhos Exatos
              </h2>
            </div>
          </div>

          <button
            onClick={onClose}
            className="w-10 h-10 flex items-center justify-center text-[#C5B8AC] hover:text-white hover:bg-white/10 transition-colors"
            aria-label="Fechar guia de medidas"
          >
            <X className="w-6 h-6" />
          </button>
        </div>

        {/* Category Tabs */}
        <div className="bg-white border-b border-[#E2D7C9] px-6 flex flex-wrap gap-2 pt-3 shrink-0">
          <button
            onClick={() => setActiveTab("vestuario")}
            className={`px-4 py-2.5 text-xs sm:text-sm font-semibold tracking-wide border-b-2 transition-all ${
              activeTab === "vestuario"
                ? "border-[#6B1D2F] text-[#6B1D2F]"
                : "border-transparent text-[#736357] hover:text-[#221F1D]"
            }`}
          >
            Palas, Ponchos & Capas
          </button>

          <button
            onClick={() => setActiveTab("bombacha")}
            className={`px-4 py-2.5 text-xs sm:text-sm font-semibold tracking-wide border-b-2 transition-all ${
              activeTab === "bombacha"
                ? "border-[#6B1D2F] text-[#6B1D2F]"
                : "border-transparent text-[#736357] hover:text-[#221F1D]"
            }`}
          >
            Bombachas Campeiras
          </button>

          <button
            onClick={() => setActiveTab("chapeu")}
            className={`px-4 py-2.5 text-xs sm:text-sm font-semibold tracking-wide border-b-2 transition-all ${
              activeTab === "chapeu"
                ? "border-[#6B1D2F] text-[#6B1D2F]"
                : "border-transparent text-[#736357] hover:text-[#221F1D]"
            }`}
          >
            Chapéus Campeiros (cm)
          </button>
        </div>

        {/* Modal Scrollable Content */}
        <div className="overflow-y-auto p-6 space-y-8 flex-1">
          
          {/* Interactive Size Helper Card */}
          <div className="bg-white border border-[#D8C7B5] p-5 sm:p-6 shadow-sm">
            <div className="flex items-center gap-2 text-xs font-semibold uppercase tracking-wider text-[#7A4725] mb-2">
              <Sparkles className="w-4 h-4 text-[#6B1D2F]" />
              <span>Simulador Rápido: Qual tamanho você veste normalmente?</span>
            </div>
            <p className="text-xs sm:text-sm text-[#5A4D45] mb-4">
              Selecione o manequim que costuma vestir no dia a dia para ver a recomendação da modelagem gaúcha:
            </p>

            <div className="flex flex-wrap items-center gap-2 mb-4">
              {["36", "38", "40", "42", "44", "46", "48", "50+"].map((man) => (
                <button
                  key={man}
                  onClick={() => setHabitualManequim(man)}
                  className={`h-10 px-4 text-xs font-semibold border transition-all ${
                    habitualManequim === man
                      ? "bg-[#6B1D2F] text-white border-[#6B1D2F] shadow-sm scale-105"
                      : "bg-[#FAF7F2] text-[#4A3E38] border-[#D8C7B5] hover:border-[#6B1D2F]"
                  }`}
                >
                  Manequim {man}
                </button>
              ))}
            </div>

            <div className="p-4 bg-[#FAF7F2] border-l-4 border-[#6B1D2F] flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              <div>
                <div className="text-xs font-semibold uppercase tracking-wider text-[#736357]">
                  Tamanho recomendado para manequim {habitualManequim}:
                </div>
                <div className="text-xl sm:text-2xl font-serif font-bold text-[#6B1D2F] mt-0.5">
                  Tamanho {currentRecommendation.size}
                </div>
                <p className="text-xs text-[#5A4D45] mt-1">
                  {currentRecommendation.tip}
                </p>
              </div>

              <div className="shrink-0 flex items-center gap-1.5 text-xs text-emerald-800 font-medium bg-emerald-50 px-3 py-2 border border-emerald-200">
                <Check className="w-4 h-4 text-emerald-600" />
                <span>Excelente caimento campeiro</span>
              </div>
            </div>
          </div>

          {/* Detailed Measurement Tables */}
          {activeTab === "vestuario" && (
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="font-serif text-lg sm:text-xl font-semibold text-[#221F1D]">
                    Tabela de Medidas: Palas, Ponchos & Capas
                  </h3>
                  <p className="text-xs text-[#736357]">
                    Medidas corporais e de comprimento em centímetros (cm):
                  </p>
                </div>
                <span className="text-xs text-[#7A4725] font-semibold uppercase tracking-wider hidden sm:inline">
                  Padrão Regional RS
                </span>
              </div>

              <div className="overflow-x-auto border border-[#D8C7B5] bg-white">
                <table className="w-full text-left text-xs sm:text-sm">
                  <thead className="bg-[#221F1D] text-white font-semibold text-[11px] uppercase tracking-wider">
                    <tr>
                      <th className="py-3 px-4">Tamanho</th>
                      <th className="py-3 px-4">Manequim</th>
                      <th className="py-3 px-4">Busto / Tórax</th>
                      <th className="py-3 px-4">Cintura</th>
                      <th className="py-3 px-4">Quadril</th>
                      <th className="py-3 px-4">Comprimento</th>
                      <th className="py-3 px-4 hidden md:table-cell">Caimento</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-[#E2D7C9] text-[#4A3E38]">
                    {sizeGuideData.vestuario.map((item) => {
                      const isCurrentlySelected = selectedSize === item.size;
                      return (
                        <tr 
                          key={item.size}
                          className={`hover:bg-[#FAF7F2] transition-colors ${
                            isCurrentlySelected ? "bg-amber-50/80 font-semibold" : ""
                          }`}
                        >
                          <td className="py-3.5 px-4 font-bold text-[#6B1D2F]">
                            {item.size}
                            {isCurrentlySelected && (
                              <span className="ml-1 text-[10px] bg-[#6B1D2F] text-white px-1.5 py-0.5 uppercase tracking-wider">
                                Ativo
                              </span>
                            )}
                          </td>
                          <td className="py-3.5 px-4 font-medium">{item.manequim}</td>
                          <td className="py-3.5 px-4 tabular-nums">{item.busto}</td>
                          <td className="py-3.5 px-4 tabular-nums">{item.cintura}</td>
                          <td className="py-3.5 px-4 tabular-nums">{item.quadril}</td>
                          <td className="py-3.5 px-4 tabular-nums font-semibold">{item.comprimento}</td>
                          <td className="py-3.5 px-4 text-xs text-[#736357] hidden md:table-cell">
                            {item.descricao}
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {activeTab === "bombacha" && (
            <div className="space-y-4">
              <div>
                <h3 className="font-serif text-lg sm:text-xl font-semibold text-[#221F1D]">
                  Tabela de Medidas: Bombachas Campeiras
                </h3>
                <p className="text-xs text-[#736357]">
                  Medidas de cintura e comprimento da perna com cós e favos tradicionais:
                </p>
              </div>

              <div className="overflow-x-auto border border-[#D8C7B5] bg-white">
                <table className="w-full text-left text-xs sm:text-sm">
                  <thead className="bg-[#221F1D] text-white font-semibold text-[11px] uppercase tracking-wider">
                    <tr>
                      <th className="py-3 px-4">Tamanho</th>
                      <th className="py-3 px-4">Equivalente</th>
                      <th className="py-3 px-4">Cintura (cm)</th>
                      <th className="py-3 px-4">Quadril (cm)</th>
                      <th className="py-3 px-4">Comprimento</th>
                      <th className="py-3 px-4 hidden md:table-cell">Dica de Uso</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-[#E2D7C9] text-[#4A3E38]">
                    {sizeGuideData.bombachas.map((item) => (
                      <tr key={item.size} className="hover:bg-[#FAF7F2] transition-colors">
                        <td className="py-3.5 px-4 font-bold text-[#6B1D2F]">{item.size}</td>
                        <td className="py-3.5 px-4">{item.manequim}</td>
                        <td className="py-3.5 px-4 tabular-nums font-semibold">{item.cintura}</td>
                        <td className="py-3.5 px-4 tabular-nums">{item.quadril}</td>
                        <td className="py-3.5 px-4 tabular-nums">{item.comprimento}</td>
                        <td className="py-3.5 px-4 text-xs text-[#736357] hidden md:table-cell">
                          {item.descricao}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {activeTab === "chapeu" && (
            <div className="space-y-4">
              <div>
                <h3 className="font-serif text-lg sm:text-xl font-semibold text-[#221F1D]">
                  Tabela de Tamanhos: Chapéus Campeiros
                </h3>
                <p className="text-xs text-[#736357]">
                  A numeração do chapéu campeiro corresponde exatamente à circunferência da cabeça em centímetros:
                </p>
              </div>

              <div className="overflow-x-auto border border-[#D8C7B5] bg-white">
                <table className="w-full text-left text-xs sm:text-sm">
                  <thead className="bg-[#221F1D] text-white font-semibold text-[11px] uppercase tracking-wider">
                    <tr>
                      <th className="py-3 px-4">Número do Chapéu</th>
                      <th className="py-3 px-4">Encaixe</th>
                      <th className="py-3 px-4">Circunferência da Cabeça</th>
                      <th className="py-3 px-4">Descrição</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-[#E2D7C9] text-[#4A3E38]">
                    {sizeGuideData.chapeus.map((item) => (
                      <tr key={item.size} className="hover:bg-[#FAF7F2] transition-colors">
                        <td className="py-3.5 px-4 font-bold text-[#6B1D2F]">{item.size}</td>
                        <td className="py-3.5 px-4 font-medium">{item.manequim}</td>
                        <td className="py-3.5 px-4 tabular-nums font-semibold">{item.circunferencia}</td>
                        <td className="py-3.5 px-4 text-xs text-[#736357]">{item.descricao}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {/* How to Measure Step-by-Step */}
          <div className="p-6 bg-white border border-[#D8C7B5] space-y-4">
            <div className="flex items-center gap-2 text-xs font-semibold uppercase tracking-wider text-[#221F1D]">
              <HelpCircle className="w-4 h-4 text-[#7A4725]" />
              <span>Como tirar suas medidas em casa com fita métrica:</span>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4 text-xs leading-relaxed text-[#5A4D45]">
              {sizeGuideData.howToMeasureTips.map((tip, idx) => (
                <div key={idx} className="p-3 bg-[#FAF7F2] border border-[#E2D7C9] space-y-1">
                  <div className="font-semibold text-[#221F1D]">{tip.step}</div>
                  <p>{tip.tip}</p>
                </div>
              ))}
            </div>
          </div>

        </div>

        {/* Modal Footer with Direct WhatsApp Help */}
        <div className="bg-[#FAF7F2] border-t border-[#D8C7B5] px-6 py-4 flex flex-col sm:flex-row items-center justify-between gap-4 shrink-0">
          <div className="text-xs text-[#5A4D45] text-center sm:text-left">
            Ainda com dúvida sobre qual tamanho escolher? Nossa equipe confere as medidas com você no WhatsApp.
          </div>

          <div className="flex items-center gap-3 w-full sm:w-auto">
            <button
              onClick={onClose}
              className="w-1/2 sm:w-auto px-5 py-2.5 text-xs font-semibold uppercase tracking-wider text-[#4A3E38] border border-[#D8C7B5] hover:bg-white transition-colors"
            >
              Fechar
            </button>

            <a
              href={`https://wa.me/5553984450638?text=${encodeURIComponent(
                `Olá! Gostaria de ajuda para conferir as medidas e tamanhos da ${productName || "vitrine da Flavinha Store"}.`
              )}`}
              target="_blank"
              rel="noopener noreferrer"
              className="w-1/2 sm:w-auto inline-flex items-center justify-center gap-2 px-6 py-2.5 text-xs font-semibold uppercase tracking-wider text-white bg-[#6B1D2F] hover:bg-[#521523] transition-colors shadow-sm"
            >
              <MessageCircle className="w-4 h-4 text-emerald-300" />
              <span>Tirar Dúvida no WhatsApp</span>
            </a>
          </div>
        </div>

      </div>
    </div>
  );
};
