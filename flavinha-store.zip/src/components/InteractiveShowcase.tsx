import React, { useState, useEffect, useRef } from 'react';
import { ChevronLeft, ChevronRight, MessageCircle, Sparkles, Check, ArrowRight, Ruler, Plus, Minus, Info } from 'lucide-react';
import { flavinhaConfig, ProductItem } from '../data/flavinhaConfig';
import { SizeGuideModal } from './SizeGuideModal';

export const InteractiveShowcase: React.FC = () => {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [selectedSizes, setSelectedSizes] = useState<Record<string, string>>({
    "peca-1": "M",
    "peca-2": "M",
    "peca-3": "56",
    "peca-4": "M",
    "peca-5": "38",
  });
  const [expandedSizes, setExpandedSizes] = useState<Record<string, boolean>>({});
  const [isSizeGuideOpen, setIsSizeGuideOpen] = useState(false);
  const [imageLoaded, setImageLoaded] = useState<Record<string, boolean>>({});

  const touchStartX = useRef<number | null>(null);
  const touchEndX = useRef<number | null>(null);

  const products = flavinhaConfig.showcaseProducts;
  const currentProduct: ProductItem = products[currentIndex] || products[0];
  const currentSize = selectedSizes[currentProduct.id] || currentProduct.defaultSize || "M";
  const isExpanded = !!expandedSizes[currentProduct.id];

  const handlePrev = () => {
    setCurrentIndex((prev) => (prev === 0 ? products.length - 1 : prev - 1));
  };

  const handleNext = () => {
    setCurrentIndex((prev) => (prev === products.length - 1 ? 0 : prev + 1));
  };

  const handleSelectSize = (productId: string, size: string) => {
    setSelectedSizes((prev) => ({
      ...prev,
      [productId]: size,
    }));
  };

  const toggleExpandSizes = (productId: string) => {
    setExpandedSizes((prev) => ({
      ...prev,
      [productId]: !prev[productId],
    }));
  };

  // Touch swipe support for mobile
  const handleTouchStart = (e: React.TouchEvent) => {
    touchStartX.current = e.targetTouches[0].clientX;
  };

  const handleTouchMove = (e: React.TouchEvent) => {
    touchEndX.current = e.targetTouches[0].clientX;
  };

  const handleTouchEnd = () => {
    if (!touchStartX.current || !touchEndX.current) return;
    const distance = touchStartX.current - touchEndX.current;
    const minSwipeDistance = 50;

    if (distance > minSwipeDistance) {
      handleNext();
    } else if (distance < -minSwipeDistance) {
      handlePrev();
    }

    touchStartX.current = null;
    touchEndX.current = null;
  };

  // Keyboard navigation
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'ArrowLeft') handlePrev();
      if (e.key === 'ArrowRight') handleNext();
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, []);

  const whatsAppLink = flavinhaConfig.getWhatsAppProductLink(currentProduct.name, currentSize);

  // Auxílio de medição detalhado em tempo real para o tamanho selecionado
  const getMeasurementDetails = (product: ProductItem, size: string) => {
    if (product.sizeType === "chapeu") {
      const item = flavinhaConfig.sizeGuideData.chapeus.find((c) => c.size === size);
      if (item) {
        return {
          title: `Chapéu Número ${size} (${item.manequim})`,
          details: `Circunferência da cabeça: ${item.circunferencia}`,
          desc: item.descricao,
        };
      }
      return {
        title: `Chapéu ${size}`,
        details: "Medida personalizada",
        desc: "Conferido diretamente com a loja pelo WhatsApp",
      };
    }

    if (product.sizeType === "bombacha") {
      const item = flavinhaConfig.sizeGuideData.bombachas.find((b) => b.size === size);
      if (item) {
        return {
          title: `Bombacha Tamanho ${size} (${item.manequim})`,
          details: `Cintura: ${item.cintura} · Quadril: ${item.quadril} · Comprimento: ${item.comprimento}`,
          desc: item.descricao,
        };
      }
      return {
        title: `Bombacha ${size}`,
        details: "Medidas personalizadas",
        desc: "Ajustada conforme suas medidas de perna e cintura",
      };
    }

    // Vestuário (Palas, Ponchos, Capas)
    const item = flavinhaConfig.sizeGuideData.vestuario.find((v) => v.size === size);
    if (item) {
      return {
        title: `Tamanho ${size} (Veste Manequim ${item.manequim})`,
        details: `Busto: ${item.busto} · Cintura: ${item.cintura} · Quadril: ${item.quadril} · Comprimento: ${item.comprimento}`,
        desc: item.descricao,
      };
    }

    return {
      title: `Tamanho ${size}`,
      details: "Medidas sob consulta",
      desc: "Consulte detalhes de caimento com nossa equipe no WhatsApp",
    };
  };

  const currentMeasurement = getMeasurementDetails(currentProduct, currentSize);

  // Sizes to display: primary sizes + moreSizes if expanded
  const displaySizes = isExpanded ? currentProduct.sizes : currentProduct.primarySizes;

  return (
    <section 
      id="vitrine"
      className="relative pt-8 pb-16 lg:py-20 transition-colors duration-700 ease-out overflow-hidden"
      style={{
        backgroundColor: currentProduct.accentTone.subtle ? `${currentProduct.accentTone.subtle}2B` : '#F8F5F0',
      }}
      onTouchStart={handleTouchStart}
      onTouchMove={handleTouchMove}
      onTouchEnd={handleTouchEnd}
    >
      {/* Background soft ambient radial gradient based on active product tone */}
      <div 
        className="absolute inset-0 pointer-events-none opacity-50 transition-opacity duration-1000"
        style={{
          background: `radial-gradient(circle at 45% 40%, ${currentProduct.accentTone.subtle}, transparent 70%)`
        }}
      />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        
        {/* Editorial Section Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-8 sm:mb-12 border-b border-[#E8DFD3] pb-6 gap-4">
          <div>
            <div className="flex items-center gap-2 text-xs font-semibold tracking-widest text-[#7A4725] uppercase mb-2">
              <span>{flavinhaConfig.copy.heroKicker}</span>
              <span aria-hidden="true">·</span>
              <span>{flavinhaConfig.business.cityState}</span>
            </div>
            <h1 className="font-serif text-3xl sm:text-5xl lg:text-6xl font-medium tracking-tight text-[#221F1D]">
              Vitrine de Tradição
            </h1>
          </div>

          {/* Slide Progress Counter and Navigation Arrows */}
          <div className="flex items-center gap-4">
            <span className="text-sm font-medium text-[#736357] tabular-nums">
              <strong className="text-[#6B1D2F] text-xl font-serif">0{currentIndex + 1}</strong> / 0{products.length}
            </span>
            <div className="flex items-center gap-2">
              <button
                onClick={handlePrev}
                className="w-11 h-11 flex items-center justify-center border border-[#D8C7B5] bg-white/90 hover:bg-white text-[#221F1D] transition-colors shadow-sm active:scale-95"
                aria-label="Peça anterior"
              >
                <ChevronLeft className="w-5 h-5" />
              </button>
              <button
                onClick={handleNext}
                className="w-11 h-11 flex items-center justify-center border border-[#D8C7B5] bg-white/90 hover:bg-white text-[#221F1D] transition-colors shadow-sm active:scale-95"
                aria-label="Próxima peça"
              >
                <ChevronRight className="w-5 h-5" />
              </button>
            </div>
          </div>
        </div>

        {/* The Showcase Core Stage */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 lg:gap-14 items-center">
          
          {/* Left Column: Floating Product Imagery (Protagonist) */}
          <div className="lg:col-span-7 flex justify-center items-center relative">
            <div className="relative w-full max-w-lg aspect-[3/4] sm:aspect-[4/5] flex items-center justify-center">
              
              {/* Soft pedestal shadow */}
              <div className="absolute -bottom-6 w-3/4 h-8 bg-[#3E2B1E]/15 blur-xl rounded-full" />

              {/* Main Product Image Container */}
              <div className="relative w-full h-full overflow-hidden bg-[#EFEAE2] border border-[#DDD3C5] shadow-md">
                <img
                  key={currentProduct.id}
                  src={currentProduct.imageUrl}
                  alt={currentProduct.altText}
                  referrerPolicy="no-referrer"
                  onLoad={() => setImageLoaded((prev) => ({ ...prev, [currentProduct.id]: true }))}
                  className={`w-full h-full object-cover object-center transition-all duration-700 ease-out hover:scale-105 ${
                    imageLoaded[currentProduct.id] ? 'opacity-100 scale-100' : 'opacity-0 scale-95'
                  }`}
                />

                {/* Loading / Fallback placeholder */}
                {!imageLoaded[currentProduct.id] && (
                  <div className="absolute inset-0 flex flex-col items-center justify-center bg-[#EFEAE2] text-[#8C7A6B] p-6 text-center">
                    <Sparkles className="w-8 h-8 mb-2 animate-pulse text-[#7A4725]" />
                    <span className="text-xs uppercase tracking-wider font-medium">Carregando peça campeira...</span>
                  </div>
                )}

                {/* Subtle illustrative badge */}
                <div className="absolute bottom-3 left-3 bg-white/95 backdrop-blur-sm px-2.5 py-1 text-[11px] font-medium text-[#5C4535] border border-[#DDD3C5]">
                  Foto ilustrativa de estilo campeiro
                </div>
              </div>
            </div>
          </div>

          {/* Right Column: Editorial Details & Direct WhatsApp Action */}
          <div className="lg:col-span-5 flex flex-col justify-center space-y-6">
            
            {/* Category / Status line */}
            <div className="flex items-center gap-3 text-xs tracking-wider uppercase text-[#736357]">
              <span className="font-semibold text-[#6B1D2F]">{currentProduct.category}</span>
              <span aria-hidden="true">·</span>
              <span className="font-medium">{currentProduct.statusBadge}</span>
            </div>

            {/* Product Name */}
            <div>
              <h2 className="font-serif text-3xl sm:text-4xl lg:text-5xl font-semibold text-[#221F1D] tracking-tight leading-tight">
                {currentProduct.name}
              </h2>
              <p className="mt-3 text-[#5A4D45] text-sm sm:text-base leading-relaxed">
                {currentProduct.descriptionPlaceholder}
              </p>
            </div>

            {/* Price section - Strictly adhering to "Consulte o valor" */}
            <div className="py-3.5 border-y border-[#E2D7C9]">
              <div className="text-xs uppercase tracking-wider text-[#7A4725] font-semibold">Valor da peça</div>
              <div className="text-2xl sm:text-3xl font-serif font-medium text-[#221F1D] mt-1">
                {currentProduct.price}
              </div>
              <div className="text-xs text-[#736357] mt-0.5">
                {currentProduct.priceNote}
              </div>
            </div>

            {/* Size Selector with '+' expander and Guia de Medidas */}
            <div className="space-y-3">
              <div className="flex flex-wrap items-center justify-between gap-2 text-xs">
                <span className="font-semibold uppercase tracking-wider text-[#4A3E38]">
                  Selecione o tamanho:
                </span>
                
                {/* Button to open the full interactive Measurement Guide */}
                <button
                  type="button"
                  onClick={() => setIsSizeGuideOpen(true)}
                  className="inline-flex items-center gap-1.5 text-xs font-semibold text-[#6B1D2F] hover:text-[#521523] underline underline-offset-2 transition-colors cursor-pointer"
                >
                  <Ruler className="w-3.5 h-3.5 text-[#7A4725]" />
                  <span>Guia de Medidas & Tamanhos</span>
                </button>
              </div>

              {/* Size Buttons Row + the '+' Button */}
              <div className="flex flex-wrap items-center gap-2">
                {displaySizes.map((size) => {
                  const isSelected = currentSize === size;
                  return (
                    <button
                      key={size}
                      type="button"
                      onClick={() => handleSelectSize(currentProduct.id, size)}
                      className={`h-11 min-w-[50px] px-4 text-xs font-semibold tracking-wider transition-all border ${
                        isSelected
                          ? 'bg-[#6B1D2F] text-white border-[#6B1D2F] shadow-sm scale-105'
                          : 'bg-white text-[#4A3E38] border-[#D8C7B5] hover:border-[#6B1D2F] hover:bg-[#FAF7F2]'
                      }`}
                    >
                      {size}
                    </button>
                  );
                })}

                {/* The '+' Expand/Collapse Button */}
                <button
                  type="button"
                  onClick={() => toggleExpandSizes(currentProduct.id)}
                  className={`h-11 px-3.5 text-xs font-semibold tracking-wide border flex items-center gap-1.5 transition-all cursor-pointer ${
                    isExpanded
                      ? 'bg-[#221F1D] text-white border-[#221F1D]'
                      : 'bg-[#FAF7F2] text-[#6B1D2F] border-[#D8C7B5] hover:border-[#6B1D2F] hover:bg-white'
                  }`}
                  title={isExpanded ? "Ocultar tamanhos adicionais" : "Ver mais opções de tamanhos"}
                >
                  {isExpanded ? (
                    <>
                      <Minus className="w-3.5 h-3.5" />
                      <span>Menos</span>
                    </>
                  ) : (
                    <>
                      <Plus className="w-3.5 h-3.5" />
                      <span>Mais tamanhos</span>
                    </>
                  )}
                </button>
              </div>

              {/* Auxílio de Medição Dinâmico para o tamanho selecionado (Responde à dúvida do usuário) */}
              <div className="p-3.5 bg-white border border-[#DDD3C5] shadow-xs space-y-1 transition-all">
                <div className="flex items-center justify-between text-xs">
                  <span className="font-bold text-[#6B1D2F]">
                    {currentMeasurement.title}
                  </span>
                  <button
                    onClick={() => setIsSizeGuideOpen(true)}
                    className="text-[11px] text-[#7A4725] hover:underline font-medium inline-flex items-center gap-1"
                  >
                    <Info className="w-3 h-3" />
                    <span>Ver tabela completa</span>
                  </button>
                </div>
                <div className="text-xs font-medium text-[#221F1D] tabular-nums">
                  {currentMeasurement.details}
                </div>
                <p className="text-[11px] text-[#736357]">
                  {currentMeasurement.desc}
                </p>
              </div>
            </div>

            {/* WhatsApp Purchase CTA */}
            <div className="pt-2 space-y-3">
              <a
                href={whatsAppLink}
                target="_blank"
                rel="noopener noreferrer"
                className="w-full inline-flex items-center justify-center gap-3 py-4 px-6 text-sm font-semibold uppercase tracking-wider text-white bg-[#6B1D2F] hover:bg-[#521523] transition-all shadow-md active:scale-[0.99] group"
              >
                <MessageCircle className="w-5 h-5 text-emerald-300 group-hover:scale-110 transition-transform" />
                <span>{flavinhaConfig.copy.heroCtaPrimary} (Tamanho {currentSize})</span>
                <ArrowRight className="w-4 h-4 ml-1 opacity-80 group-hover:translate-x-1 transition-transform" />
              </a>

              <div className="flex items-center justify-center gap-2 text-xs text-[#736357]">
                <Check className="w-3.5 h-3.5 text-emerald-700" />
                <span>Atendimento direto pelo WhatsApp: {flavinhaConfig.business.phoneDisplay}</span>
              </div>
            </div>

          </div>

        </div>

        {/* Thumbnail Selector Strip */}
        <div className="mt-12 sm:mt-16 pt-8 border-t border-[#E8DFD3]">
          <div className="text-xs font-semibold uppercase tracking-wider text-[#7A4725] mb-4">
            Peças em destaque na vitrine:
          </div>
          <div className="grid grid-cols-5 gap-2 sm:gap-4">
            {products.map((item, idx) => {
              const isActive = idx === currentIndex;
              return (
                <button
                  key={item.id}
                  onClick={() => setCurrentIndex(idx)}
                  className={`group relative text-left p-2 sm:p-3 border transition-all ${
                    isActive 
                      ? 'border-[#6B1D2F] bg-white shadow-sm' 
                      : 'border-[#DDD3C5] bg-white/60 hover:bg-white hover:border-[#B5A593]'
                  }`}
                  aria-label={`Ver ${item.name}`}
                >
                  <div className="aspect-[3/4] w-full overflow-hidden bg-[#EFEAE2] mb-2">
                    <img
                      src={item.imageUrl}
                      alt={item.name}
                      referrerPolicy="no-referrer"
                      className="w-full h-full object-cover object-center group-hover:scale-105 transition-transform duration-300"
                    />
                  </div>
                  <div className="text-[11px] font-semibold text-[#221F1D] truncate">
                    {item.name}
                  </div>
                  <div className="text-[10px] text-[#736357] hidden sm:block truncate">
                    {item.price}
                  </div>
                  {isActive && (
                    <div className="absolute top-0 left-0 right-0 h-0.5 bg-[#6B1D2F]" />
                  )}
                </button>
              );
            })}
          </div>
        </div>

      </div>

      {/* Interactive Size & Measurement Guide Modal */}
      <SizeGuideModal
        isOpen={isSizeGuideOpen}
        onClose={() => setIsSizeGuideOpen(false)}
        initialCategory={currentProduct.sizeType}
        selectedSize={currentSize}
        productName={currentProduct.name}
      />
    </section>
  );
};
