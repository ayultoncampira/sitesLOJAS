import React, { useState } from 'react';
import { MessageCircle, Menu, X } from 'lucide-react';
import { flavinhaConfig } from '../data/flavinhaConfig';

export const Navbar: React.FC = () => {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  return (
    <header className="sticky top-0 z-40 bg-[#F8F5F0]/95 backdrop-blur-md border-b border-[#E8DFD3] transition-colors">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-20 flex items-center justify-between">
        {/* Zone 1: Single text element brand wordmark */}
        <div className="flex flex-col">
          <a 
            href="#" 
            className="font-serif text-2xl sm:text-3xl font-semibold tracking-tight text-[#221F1D] hover:text-[#6B1D2F] transition-colors"
          >
            {flavinhaConfig.business.name}
          </a>
        </div>

        {/* Zone 2: Clean text navigation links */}
        <nav className="hidden md:flex items-center gap-8 text-sm font-medium text-[#4A3E38]">
          <a href="#vitrine" className="hover:text-[#6B1D2F] transition-colors">Vitrine Campeira</a>
          <a href="#sobre" className="hover:text-[#6B1D2F] transition-colors">A Loja</a>
          <a href="#colecoes" className="hover:text-[#6B1D2F] transition-colors">Palas & Coleções</a>
          <a href="#localizacao" className="hover:text-[#6B1D2F] transition-colors">Localização em Bagé</a>
          <a 
            href={flavinhaConfig.business.instagramUrl} 
            target="_blank" 
            rel="noopener noreferrer" 
            className="hover:text-[#6B1D2F] transition-colors"
          >
            Instagram
          </a>
        </nav>

        {/* Zone 3: 1 primary action */}
        <div className="flex items-center gap-3">
          <a
            href={flavinhaConfig.getWhatsAppGeneralLink()}
            target="_blank"
            rel="noopener noreferrer"
            className="hidden sm:inline-flex items-center gap-2 px-5 py-2.5 text-xs font-semibold text-white bg-[#6B1D2F] hover:bg-[#521523] rounded-none transition-all shadow-sm tracking-wider uppercase whitespace-nowrap active:scale-95"
          >
            <MessageCircle className="w-4 h-4 text-emerald-300" />
            <span>WhatsApp</span>
          </a>

          {/* Mobile hamburger button */}
          <button
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="md:hidden p-2 text-[#4A3E38] hover:text-[#221F1D]"
            aria-label="Abrir menu"
          >
            {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>
        </div>
      </div>

      {/* Mobile navigation drawer */}
      {mobileMenuOpen && (
        <div className="md:hidden bg-[#F8F5F0] border-b border-[#E8DFD3] px-6 py-6 space-y-4 shadow-lg animate-in fade-in slide-in-from-top-2 duration-150">
          <div className="flex flex-col space-y-3 text-base font-medium text-[#221F1D]">
            <a 
              href="#vitrine" 
              onClick={() => setMobileMenuOpen(false)}
              className="py-1 border-b border-[#E8DFD3] hover:text-[#6B1D2F]"
            >
              Vitrine Campeira
            </a>
            <a 
              href="#sobre" 
              onClick={() => setMobileMenuOpen(false)}
              className="py-1 border-b border-[#E8DFD3] hover:text-[#6B1D2F]"
            >
              Sobre a Loja
            </a>
            <a 
              href="#colecoes" 
              onClick={() => setMobileMenuOpen(false)}
              className="py-1 border-b border-[#E8DFD3] hover:text-[#6B1D2F]"
            >
              Palas, Ponchos & Bombachas
            </a>
            <a 
              href="#localizacao" 
              onClick={() => setMobileMenuOpen(false)}
              className="py-1 border-b border-[#E8DFD3] hover:text-[#6B1D2F]"
            >
              Localização em Bagé - RS
            </a>
            <a 
              href={flavinhaConfig.business.instagramUrl} 
              target="_blank" 
              rel="noopener noreferrer"
              onClick={() => setMobileMenuOpen(false)}
              className="py-1 hover:text-[#6B1D2F]"
            >
              Instagram @storeflavinha
            </a>
          </div>
          <div className="pt-2">
            <a
              href={flavinhaConfig.getWhatsAppGeneralLink()}
              target="_blank"
              rel="noopener noreferrer"
              className="w-full inline-flex items-center justify-center gap-2 py-3 px-4 text-xs font-semibold uppercase tracking-wider text-white bg-[#6B1D2F] hover:bg-[#521523] transition-colors"
            >
              <MessageCircle className="w-4 h-4 text-emerald-300" />
              <span>Falar no WhatsApp ({flavinhaConfig.business.phoneDisplay})</span>
            </a>
          </div>
        </div>
      )}
    </header>
  );
};
